Topics: Novel Nature-Inspired Selection Strategies for Digital Image Evolution of Artwork
<p>Team member:
Thi Tuong Vy Vu - 1391873<br>
Nguyen Hoang Nam - 1403596<br>
Muhammad Hassan Sultan -1365427<br>
Karan Pratik Kumar - 1343915<br>
Joanna Galaszewska - 134494</p>
<p>Github link: https://github.com/Visionman123/Java-project---Digital-Image</p>
